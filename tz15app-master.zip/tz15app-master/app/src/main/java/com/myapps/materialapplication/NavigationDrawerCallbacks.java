package com.myapps.materialapplication;

public interface NavigationDrawerCallbacks {
    void onNavigationDrawerItemSelected(int position);
}
